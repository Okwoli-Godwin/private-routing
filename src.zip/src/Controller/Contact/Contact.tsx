import React from 'react'
import Cont from '../Cont/Cont'


const Contact = () => {
  return (
    <div>

      <Cont />

    </div>
  )
}

export default Contact