import React from 'react'
import Cont from './Controller/Cont/Cont'

const App = () => {
  return (
    <div>
      <Cont />
    </div>
  )
}

export default App